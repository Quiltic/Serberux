from matplotlib import pyplot as plt
import matplotlib.image as mpimg
import random, time, os, pygame
#plt.ion()

"""
Picture manipulation:
Graying !
Ungraying *
Blowing up 
Shrinking
Blurring
Other
"""
def graying(pic):
    data=mpimg.imread(pic)
    ata = []
    for a in data:
        n = []
        for b in a:
            l = float((b[0]+b[1]+b[2])/3)
            n.append([l,l,l])
        ata.append(n)

    plt.imsave(str("G"+pic),ata)

def ungraying(pic):
    #Dosent realy work.
    data=mpimg.imread(pic)
    ata = []
    known = {}
    for a in data:
        n = []
        for b in a:
            if str(b) in known:
                r, g, b = known(str(b))
            else:
                r = float(random.randrange(0,int(b[0]*255)+1)/255)
                g = float(random.randrange(0,int((b[0]-r)*255)+1)/255)
                b = float(random.randrange(0,int((b[0]-(g+r))*255)+1)/255)
                known[str(b)] = [r,g,b]

            n.append([r,g,b])
        ata.append(n)

    plt.imsave(str("UG"+pic),ata)

def enlarge(pic,enlarge):
    data=mpimg.imread(pic)
    ata = []
    for a in data:
        for d in range(enlarge):
            n = []
            for b in a:
                for c in range(enlarge):
                    n.append([b[0],b[1],b[2]])
            ata.append(n)

    plt.imsave(str("E"+pic),ata)

#Needs work    
def shrink(pic,enlarge):
    data=mpimg.imread(pic)
    ata = []
    for a in data:
        for d in range(enlarge):
            n = []
            for b in a:
                for c in range(enlarge):
                    n.append([b[0],b[1],b[2]])
            ata.append(n)

    plt.imsave(str("E"+pic),ata)
    

def cutimage(pic,size):
    data=mpimg.imread(pic)
    ata = []
    for a in range(size[1]):
        n = []
        for b in range(size[0]):
            x = data[a][b]
            n.append([x[0],x[1],x[2]])
        ata.append(n)

    plt.imsave(str("Ct"+pic),ata)

def oversave(pic,rename):
    data=mpimg.imread(pic)
    ata = []
    for a in data:
        n = []
        for b in a:
            n.append([b[0],b[1],b[2]])
        ata.append(n)
    plt.imsave(str(rename),ata)

def convert(pic,pc):    
    pygame.init()
    pygame.display.set_mode()
    image = pygame.image.load(str(pic)).convert_alpha()
    for x in range(image.get_width()):
        for y in range(image.get_height()):
            if image.get_at((x, y)) == (255, 255, 255, 255):
                image.set_at((x, y), (255, 255, 255, 0))
    pygame.image.save(image, str("redone"+pc))

for a in range(10):
    pic = str(input("Filename Must be png: ")+".png")
    #ungraying(str(q+".png"))
    cutimage(str(pic),[163,59])
    enlarge(str("Ct"+pic),5)
    #graying(str("ECt"+pic))
    #oversave(str("ECt"+pic),str("redone"+pic))
    convert(str("ECt"+pic),pic)
    os.remove(str("Ct"+ pic))
    os.remove(str("ECt"+ pic))
"""
while True:
    
    data = []
    ran = random.randrange(0,255)
    m = [[float(ran/255),float(ran/255),float(ran/255)]]
    for a in range(254):
        m.append([float((m[a][0]+random.randrange(-4,5)/255)),float((m[a][1]+random.randrange(-4,5)/255)),float((m[a][2]+random.randrange(-4,5)/255))])
    data.append(m)
    
    for a in range(254):
        m = []
        for b in range(255):
            #ran = random.randrange(0,2)
            if b == 0:
                m.append([float((data[a][b][0]+random.randrange(-4,5)%255)),float((data[a][b][1]+random.randrange(-4,5)%255)),float((data[a][b][2]+random.randrange(-4,5)%255))])
            #elif ran == 0:
            #    m.append([float((m[b-1][0]+random.randrange(-4,5)%255)),float((m[b-1][1]+random.randrange(-10,11)%255)),float((m[b-1][2]+random.randrange(-10,11)%255))])
            else:
                m.append([float((m[b-1][0]+random.randrange(-4,5)%255)),float((m[b-1][1]+random.randrange(-4,5)%255)),float((m[b-1][2]+random.randrange(-4,5)%255))])
        data.append(m)
    #print("Hello")
    '''
    ran = random.randrange(0,255)
    for b in range(255):
        d = []
        for a in range(255):
            d.append([float(a+ran/255),float(b+ran/255),float((a+b)+ran/255)])
        data.append(d)
    ""'''

    #data=mpimg.imread('pie.png')
    #print(data)
    plt.imsave("Test.png",data)
    time.sleep(1.5)
    os.remove("Test.png")
    #plt.imshow(data, interpolation='nearest')
    '''
    plt.axis("off")
    plt.show()
    time.sleep(1)
    plt.close()
    '''
    #break
"""
